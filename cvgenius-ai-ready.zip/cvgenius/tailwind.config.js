export default {content:["./index.html","./src/**/*.{ts,tsx}"],theme:{extend:{colors:{navy:"#14213d",brand:"#6d4aff"}}}}
