import { useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, ai, emptyCV, type CV, type CVData } from './lib/supabase';

const btn = 'rounded-xl px-4 py-2 font-semibold border border-navy disabled:opacity-50';
const pri = btn + ' bg-brand border-brand text-white';
const inp = 'w-full rounded-lg border border-slate-300 px-3 py-2';

function Auth({ recovery }: { recovery: boolean }) {
  const [mode, setMode] = useState<'in' | 'up' | 'reset'>('in');
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('');
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMsg('');
    if (!/^\S+@\S+\.\S+$/.test(email) && !recovery) return setMsg('Enter a valid email address.');
    if ((recovery || mode !== 'reset') && pw.length < 8) return setMsg('Password must be at least 8 characters.');
    setBusy(true);
    const r = recovery ? await supabase.auth.updateUser({ password: pw })
      : mode === 'in' ? await supabase.auth.signInWithPassword({ email, password: pw })
      : mode === 'up' ? await supabase.auth.signUp({ email, password: pw })
      : await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin });
    setBusy(false);
    if (r.error) setMsg(r.error.message);
    else if (mode === 'up') setMsg('Check your email to confirm your account.');
    else if (mode === 'reset') setMsg('If that email exists, a reset link is on its way.');
  }
  return (
    <form onSubmit={submit} className="max-w-sm mx-auto mt-20 p-6 space-y-3">
      <h1 className="text-3xl font-extrabold text-navy">CVGenius <span className="text-brand">AI</span></h1>
      <p className="text-slate-600">{recovery ? 'Choose a new password.' : mode === 'in' ? 'Sign in to your CVs.' : mode === 'up' ? 'Create your account.' : 'Reset your password.'}</p>
      {!recovery && <input className={inp} type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />}
      {(recovery || mode !== 'reset') && <input className={inp} type="password" placeholder="Password" value={pw} onChange={e => setPw(e.target.value)} />}
      {msg && <p role="alert" className="text-sm text-red-700">{msg}</p>}
      <button className={pri + ' w-full'} disabled={busy}>{busy ? 'Working…' : recovery ? 'Save password' : mode === 'in' ? 'Sign in' : mode === 'up' ? 'Create account' : 'Send reset link'}</button>
      {!recovery && <div className="text-sm flex gap-4">
        <button type="button" onClick={() => setMode(mode === 'in' ? 'up' : 'in')} className="underline">{mode === 'in' ? 'Create account' : 'Back to sign in'}</button>
        <button type="button" onClick={() => setMode('reset')} className="underline">Forgot password?</button></div>}
    </form>);
}

function Editor({ cv, onClose }: { cv: CV; onClose: () => void }) {
  const [d, setD] = useState<CVData>({ ...emptyCV, ...cv.data });
  const [title, setTitle] = useState(cv.title);
  const [status, setStatus] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: keyof CVData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setD({ ...d, [k]: e.target.value });
  async function save() {
    const { error } = await supabase.from('cvs').update({ title, data: d, updated_at: new Date().toISOString() }).eq('id', cv.id);
    setStatus(error ? 'Save failed: ' + error.message : 'Saved.');
  }
  async function help(task: string, field: 'summary' | 'experience') {
    setBusy(true); setStatus('');
    try {
      const out = await ai(task, `Name: ${d.name}\nTarget role: ${d.job}\nSkills: ${d.skills}\nExperience: ${d.experience}\nCurrent text: ${d[field]}`);
      if (confirm('AI suggestion (verify every fact before using):\n\n' + out + '\n\nReplace your text with this?')) setD({ ...d, [field]: out });
    } catch (e) { setStatus((e as Error).message); }
    setBusy(false);
  }
  return (
    <div className="grid md:grid-cols-2 gap-6 p-6 max-w-6xl mx-auto">
      <div className="space-y-3">
        <input className={inp} value={title} maxLength={120} onChange={e => setTitle(e.target.value)} aria-label="CV name" />
        <input className={inp} placeholder="Full name" value={d.name} onChange={set('name')} />
        <input className={inp} placeholder="Job title" value={d.job} onChange={set('job')} />
        <input className={inp} type="email" placeholder="Email" value={d.email} onChange={set('email')} />
        <textarea className={inp} rows={4} placeholder="Professional summary" value={d.summary} onChange={set('summary')} />
        <button className={btn} disabled={busy} onClick={() => help('summary', 'summary')}>{busy ? 'Thinking…' : 'Write summary with AI'}</button>
        <textarea className={inp} rows={6} placeholder="Work experience" value={d.experience} onChange={set('experience')} />
        <button className={btn} disabled={busy || !d.experience.trim()} onClick={() => help('improve', 'experience')}>Improve experience with AI</button>
        <textarea className={inp} rows={2} placeholder="Skills (comma separated)" value={d.skills} onChange={set('skills')} />
        <p className="text-sm text-slate-500">Never accept AI text that states something untrue. You are responsible for your CV.</p>
        <div className="flex gap-2 flex-wrap"><button className={pri} onClick={save}>Save</button><button className={btn} onClick={() => window.print()}>Print / save as PDF</button><button className={btn} onClick={onClose}>Close</button></div>
        {status && <p role="status" className="text-sm">{status}</p>}
      </div>
      <div id="paper" className="bg-white shadow-xl p-8 text-sm leading-relaxed aspect-[210/297]">
        <h1 className="text-2xl font-extrabold text-brand">{d.name || 'Your name'}</h1>
        <p className="text-slate-600">{d.job} {d.email && '· ' + d.email}</p>
        {d.summary && <><h2 className="mt-4 font-bold text-brand border-b border-brand">Summary</h2><p className="whitespace-pre-wrap">{d.summary}</p></>}
        {d.experience && <><h2 className="mt-4 font-bold text-brand border-b border-brand">Experience</h2><p className="whitespace-pre-wrap">{d.experience}</p></>}
        {d.skills && <><h2 className="mt-4 font-bold text-brand border-b border-brand">Skills</h2><p>{d.skills}</p></>}
      </div>
    </div>);
}

function Dashboard({ session }: { session: Session }) {
  const [cvs, setCvs] = useState<CV[]>([]); const [open, setOpen] = useState<CV | null>(null); const [err, setErr] = useState(''); const [loading, setLoading] = useState(true);
  async function load() {
    const { data, error } = await supabase.from('cvs').select('*').order('updated_at', { ascending: false });
    setLoading(false); if (error) setErr(error.message); else setCvs(data as CV[]);
  }
  useEffect(() => { load(); }, []);
  async function create(from?: CV) {
    const { data, error } = await supabase.from('cvs').insert({ title: from ? from.title + ' (copy)' : 'Untitled CV', data: from?.data ?? emptyCV }).select().single();
    if (error) return setErr(error.message); setOpen(data as CV);
  }
  async function del(id: string) { if (!confirm('Delete this CV? This cannot be undone.')) return; await supabase.from('cvs').delete().eq('id', id); load(); }
  if (open) return <Editor cv={open} onClose={() => { setOpen(null); load(); }} />;
  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6 flex-wrap gap-2"><h1 className="text-2xl font-extrabold text-navy">My CVs</h1>
        <div className="flex gap-2 items-center"><span className="text-sm text-slate-500">{session.user.email}</span><button className={pri} onClick={() => create()}>New CV</button><button className={btn} onClick={() => supabase.auth.signOut()}>Sign out</button></div></div>
      {err && <p role="alert" className="text-red-700">{err}</p>}
      {loading ? <p>Loading…</p> : !cvs.length ? <p className="text-slate-600">No CVs yet. Create your first one.</p> :
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{cvs.map(c => (
          <div key={c.id} className="rounded-2xl border p-4"><h2 className="font-bold">{c.title}</h2>
            <p className="text-sm text-slate-500">Updated {new Date(c.updated_at).toLocaleDateString()}</p>
            <div className="flex gap-2 mt-3"><button className={pri + ' !py-1'} onClick={() => setOpen(c)}>Edit</button><button className={btn + ' !py-1'} onClick={() => create(c)}>Duplicate</button><button className={btn + ' !py-1 text-red-700 border-red-700'} onClick={() => del(c.id)}>Delete</button></div></div>))}</div>}
    </div>);
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null); const [ready, setReady] = useState(false); const [recovery, setRecovery] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: sub } = supabase.auth.onAuthStateChange((ev, s) => { setSession(s); if (ev === 'PASSWORD_RECOVERY') setRecovery(true); if (ev === 'USER_UPDATED') setRecovery(false); });
    return () => sub.subscription.unsubscribe();
  }, []);
  if (!ready) return <p className="p-6">Loading…</p>;
  return session && !recovery ? <Dashboard session={session} /> : <Auth recovery={recovery} />;
}
