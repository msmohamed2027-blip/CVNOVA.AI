# CVGenius AI

## Run locally
1. Install Node.js 20 or newer.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and fill in your Supabase project URL and anon/public key.
4. Run `npm run dev` and open the local URL shown in the terminal.

## Required backend setup
This project uses Supabase for authentication and saving CVs. Create a Supabase project, run `supabase/schema.sql` in its SQL Editor, and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in `.env`.

The AI assistant also requires deploying `supabase/functions/ai` as a Supabase Edge Function and setting the `ANTHROPIC_API_KEY` secret on the server. Never put the Anthropic secret in frontend `.env` or client code.

## Deploy to Vercel
1. Push this project folder to a GitHub repository.
2. Import that repository at https://vercel.com/.
3. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as Vercel environment variables, then deploy.
5. In Supabase Auth URL Configuration, add your deployed Vercel URL as the site URL / allowed redirect URL.

## Current limitations
The initial project includes sign-in, CV create/edit/save/duplicate/delete, AI summary/experience assistance, and print-to-PDF. The 10 templates, cover-letter and job-analyzer screens, plan limits, and payment integration are not implemented yet. They require additional development.
