create table public.cvs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  title text not null default 'Untitled CV' check (char_length(title) <= 120),
  template int not null default 0,
  data jsonb not null default '{}',
  updated_at timestamptz not null default now()
);
alter table public.cvs enable row level security;
create policy "own cvs select" on public.cvs for select using (auth.uid() = user_id);
create policy "own cvs insert" on public.cvs for insert with check (auth.uid() = user_id);
create policy "own cvs update" on public.cvs for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own cvs delete" on public.cvs for delete using (auth.uid() = user_id);
