import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };
const RULES = "You are a CV writing assistant. Use ONLY facts the user supplied. Never invent employers, qualifications, dates, numbers or achievements. If information is missing, say what is missing. Return plain text only.";
const TASKS: Record<string, string> = {
  summary: "Write a 3-sentence professional summary from the details below.",
  improve: "Rewrite this work experience as concise, professional bullet points without adding new facts.",
  grammar: "Correct spelling and grammar only. Keep meaning and tone.",
  skills: "Suggest relevant skills implied by the details. Label them as suggestions to verify.",
  tailor: "Using the job description, suggest how to reword the CV text to fit it, without adding anything untrue.",
  missing: "List important information missing from this CV.",
  cover: "Write a personalized cover letter using only the experience given.",
  analyze: "Compare the CV to the job description: key keywords, what the employer wants, honest match score out of 100 with reasons, and suggested improvements.",
};
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "content-type": "application/json" } });
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await supa.auth.getUser();
  if (!user) return json({ error: "Please sign in." }, 401);
  const { task, text, jobDescription } = await req.json().catch(() => ({}));
  if (!TASKS[task] || typeof text !== "string" || !text.trim() || text.length > 8000 || (jobDescription && String(jobDescription).length > 8000))
    return json({ error: "Invalid request." }, 400);
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 1000, system: RULES,
      messages: [{ role: "user", content: `${TASKS[task]}\n\nCV details:\n${text}${jobDescription ? `\n\nJob description:\n${jobDescription}` : ""}` }] }),
  });
  if (!r.ok) return json({ error: "AI service error. Try again." }, 502);
  const j = await r.json();
  return json({ result: j.content?.[0]?.text ?? "" });
});
