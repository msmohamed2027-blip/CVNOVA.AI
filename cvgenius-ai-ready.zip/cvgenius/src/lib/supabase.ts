import { createClient } from '@supabase/supabase-js';
export const supabase = createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_ANON_KEY);
export type CVData = { name: string; job: string; email: string; summary: string; experience: string; skills: string };
export type CV = { id: string; title: string; template: number; data: CVData; updated_at: string };
export const emptyCV: CVData = { name: '', job: '', email: '', summary: '', experience: '', skills: '' };
export async function ai(task: string, text: string, jobDescription?: string): Promise<string> {
  const { data, error } = await supabase.functions.invoke('ai', { body: { task, text, jobDescription } });
  if (error || data?.error) throw new Error(data?.error ?? 'AI request failed.');
  return data.result as string;
}
